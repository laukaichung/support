import * as React from "react";
import {FunctionComponent} from "react";

interface Props{
  
}

const ${FILE_NAME}: FunctionComponent<Props> = ()=>{
  return (
      <div>
      </div>
  )
}


export default ${FILE_NAME};