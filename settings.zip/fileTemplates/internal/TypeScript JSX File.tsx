import * as React from "react";
import {FunctionComponent} from "react";

interface Props{
  
}

const ${name}: FunctionComponent<Props> = ()=>{
  return (
      <div>
      </div>
  )
}


export default ${name};